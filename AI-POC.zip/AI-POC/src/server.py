# import requests
# import base64
# import pandas as pd
# import json

# # html_path = r'C:\Pankaj\ProjectDetails\BCAI\Estimation Notes\Estimation Notes\outputhtml25.493.html'
# html_path = r'C:\Boeing\KendoEditor.html'
# with open(html_path, 'rb') as img:
#     html_text = img.read()

# url = 'https://bcai-test.web.boeing.com/bcai-public-api/conversation'
# headers = {
#     'accept': 'application/json',
#     'Authorization': 'basic my_token'
# }

# data = {
#     "messages": [
#         {
#             "role": "user",
#             # "content": "extract content from SECTION RULE in html format:  sub section (e) with image if any"
#             "content": "Please extract features included top 2 features "
#         },
#         {
#       "role": "user",
#       "content": [
#         {
#         "type": "text",
#         "text": f"{html_text}"
#         }
#       ]
#     }
#     ],
#     "conversation_mode": [
#         "default"
#     ],
#     "stream": "false",
#     "model": "gpt-4o-mini-us-sovereign",
#     "conversation_guid": "conversation_conveacbc6c7a-7e93-4ac3-a445-97c7a265c8c0s"
# }

# response = requests.post(url, headers=headers, json=data , verify=False)
# data = json.loads(response.text)

# for choice in data['choices']:
#         if choice['finish_reason'] == 'stop':
#             message_content = choice['message']['content']
#             print(message_content)
#         #    break  # Exit the loop once we find the desired content


# server.py
from flask import Flask, request, Response, jsonify
import requests
import certifi
import os
import json
import uuid

app = Flask(__name__)

# ---------------------------------------------------------------------
# SECURITY: Replace this with a secure mechanism (env var / secret store)
# for production. This example uses an in-file value for quick testing.
# ---------------------------------------------------------------------
BCAI_URL = "https://bcai-test.web.boeing.com/bcai-public-api/conversation"
BCAI_AUTH_VALUE = "basic Mzc1ODcwNjplYTA2YzNiZS02MDE2LTQzYjEtYTM2Ny1kM2M2NmQxOTY1YTM="  # <-- replace with your token or use env var
FRONTEND_ORIGIN = "http://localhost:3000"
REQUEST_TIMEOUT = 90
# --------------------------------------------------------------------- 

@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = FRONTEND_ORIGIN
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    response.headers["Access-Control-Allow-Methods"] = "POST, OPTIONS"
    response.headers["Content-Type"] = "application/json"
    return response

def safe_string(v):
    if v is None:
        return None
    if isinstance(v, str):
        return v
    if isinstance(v, (int, float)):
        return str(v)
    return None

@app.route("/api/conversation", methods=["OPTIONS", "POST"])
def proxy_ai():
    if request.method == "OPTIONS":
        return Response(status=204)

    try:
        payload = request.get_json(force=True)
    except Exception:
        return jsonify({"error": "Invalid or missing JSON body"}), 400

    if isinstance(payload, dict) and payload.get("messages"):
        forward_payload = payload.copy()
        conv_guid = safe_string(forward_payload.get("conversation_guid"))
        if not conv_guid:
            forward_payload["conversation_guid"] = str(uuid.uuid4())
    else:
        
        prompt = payload.get("prompt")
        if not prompt or not isinstance(prompt, str):
            return jsonify({"error": "Missing or invalid 'prompt' (must be string)"}), 400

        html = payload.get("html")
        model = payload.get("gpt-4o-mini-us-sovereign") or "gpt-4o-mini-us-sovereign"
        conversation_guid_raw = payload.get("conversation_guid")
        conversation_mode_raw = payload.get("conversation_mode")

       
        messages = [{"role": "user", "content": prompt}]

        if html:
            if isinstance(html, (bytes, bytearray)):
                try:
                    html = html.decode("utf-8", errors="ignore")
                except Exception:
                    html = str(html)
            elif not isinstance(html, str):
                html = json.dumps(html)
            messages.append({"role": "user", "content": [{"type": "text", "text": html}]})

        conv_guid = safe_string(conversation_guid_raw) or str(uuid.uuid4())

        forward_payload = {
            "messages": messages,
            "conversation_mode": ["BCAI Documentation"],
            "stream": "false",
            "model": model,
            "conversation_guid": conv_guid
        }

        if conversation_mode_raw and isinstance(conversation_mode_raw, list) and all(isinstance(x, str) for x in conversation_mode_raw):
            forward_payload["conversation_mode"] = conversation_mode_raw

    # Build headers
    headers = {"accept": "application/json", "Content-Type": "application/json"}
    if not BCAI_AUTH_VALUE:
        return jsonify({"error": "Server not configured with authorization token"}), 500

    
    low = BCAI_AUTH_VALUE.lower()
    if low.startswith("basic ") or low.startswith("bearer "):
        headers["Authorization"] = BCAI_AUTH_VALUE
    else:
        
        headers["Authorization"] = f"basic {BCAI_AUTH_VALUE}"

    try:
        resp = requests.post(
            BCAI_URL,
            json=forward_payload,
            headers=headers,
            timeout=REQUEST_TIMEOUT,
            verify=False
        )
    except requests.RequestException as e:
        app.logger.exception("Error forwarding request to BCAI")
        return jsonify({"error": "Proxy request failed", "details": str(e)}), 502

    content_type = resp.headers.get("Content-Type", "application/json")
    return Response(resp.content, status=resp.status_code, content_type=content_type)


if __name__ == "__main__":
    port = int(os.getenv("PORT", "3001"))
    app.run(host="0.0.0.0", port=port, debug=True)