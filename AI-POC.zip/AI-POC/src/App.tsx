// src/EditorInlineAIPromptWithMenuFix.tsx
import React from 'react';
import {
  InlineAIPrompt,
  InlineAIPromptOutputInterface,
  CommandItemInterface,
  OutputActionInterface,
} from '@progress/kendo-react-conversational-ui';
import { Editor, EditorTools } from '@progress/kendo-react-editor';
import '@progress/kendo-theme-default/dist/all.css';
import content from './shared-ed-content-overview.tsx'; 

const commands: CommandItemInterface[] = [
  { id: 'rewrite', text: 'Rewrite', prompt: (s: string) => `Rewrite the following text: ${s}` },
  { id: 'fix-spelling', text: 'Fix Spelling', prompt: (s: string) => `Fix spelling and grammar: ${s}` },
  { id: 'change-tone', text: 'Change Tone', prompt: (s: string) => `Change tone to professional: ${s}` },
];

const outputActions: OutputActionInterface[] = [
  { id: 'copy', text: 'Copy' },
  { id: 'insert', text: 'Insert' },
  { id: 'replace', text: 'Replace' },
  { id: 'discard', text: 'Discard' },
];

const {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Subscript,
  Superscript,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Indent,
  Outdent,
  OrderedList,
  UnorderedList,
  Undo,
  Redo,
  FontSize,
  FontName,
  FormatBlock,
  Link,
  Unlink,
  InsertImage,
  ViewHtml,
  InsertTable,
  AddRowBefore,
  AddRowAfter,
  AddColumnBefore,
  AddColumnAfter,
  DeleteRow,
  DeleteColumn,
  DeleteTable,
  MergeCells,
  SplitCell,
} = EditorTools;

/*
  getSuggestion: calls your backend proxy at /api/ai.
  If you don't use CRA proxy, change url to full backend address,
  e.g. "http://localhost:3001/api/ai".
*/
// const getSuggestion = async (
//   prompt: string,
//   selectedText?: string,
//   signal?: AbortSignal
// ): Promise<string> => {
//   const messages: any[] = [{ role: 'user', content: prompt }];

//   if (selectedText && selectedText.trim().length > 0) {
//     messages.push({
//       role: 'user',
//       content: [{ type: 'text', text: selectedText }],
//     });
//   }

//   const payload = {
//     messages,
//     conversation_mode: ['default'],
//     stream: 'false',
//     model: 'gpt-4o-mini-us-sovereign',
//   };

//   const url = 'https://api/ai'; // adjust if needed

//   const res = await fetch(url, {
//     method: 'POST',
//     headers: { 'Content-Type': 'application/json' },
//     body: JSON.stringify(payload),
//     signal,
//   });

//   if (!res.ok) {
//     const text = await res.text();
//     throw new Error(`HTTP ${res.status}: ${text}`);
//   }

//   const result = await res.json();

//   // Try to handle multiple response shapes:
//   if (Array.isArray(result.choices)) {
//     for (const choice of result.choices) {
//       if (choice.finish_reason === 'stop' && choice.message) {
//         if (typeof choice.message.content === 'string') return choice.message.content;
//         if (choice.message.content?.text) return choice.message.content.text;
//         return JSON.stringify(choice.message.content);
//       }
//     }
//     const c = result.choices[0];
//     if (c?.message) {
//       if (typeof c.message.content === 'string') return c.message.content;
//       if (c.message.content?.text) return c.message.content.text;
//       return JSON.stringify(c.message.content);
//     }
//   }

//   if (Array.isArray(result.messages) && result.messages[0]?.contents) {
//     try {
//       return result.messages[0].contents[0].text;
//     } catch {}
//   }

//   if (typeof result === 'string') return result;
//   if (result?.message && typeof result.message === 'string') return result.message;
//   if (result?.message?.content && typeof result.message.content === 'string') return result.message.content;

//   return JSON.stringify(result);
// };

// Replace your existing getSuggestion with this
const getSuggestion = async (
  prompt: string,
  htmlContent?: string,
  signal?: AbortSignal
): Promise<string> => {
  const body = { prompt, html: htmlContent };

  const url = 'http://localhost:3001/api/conversation';

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HTTP ${res.status}: ${text}`);
  }

  const result = await res.json();

  // Try multiple common response shapes
  if (Array.isArray(result.choices)) {
    for (const choice of result.choices) {
      if (choice.finish_reason === 'stop' && choice.message) {
        if (typeof choice.message.content === 'string') return choice.message.content;
        if (choice.message.content?.text) return choice.message.content.text;
        return JSON.stringify(choice.message.content);
      }
    }
    const c = result.choices[0];
    if (c?.message) {
      if (typeof c.message.content === 'string') return c.message.content;
      if (c.message.content?.text) return c.message.content.text;
      return JSON.stringify(c.message.content);
    }
  }

  if (Array.isArray(result.messages) && result.messages[0]?.contents) {
    try {
      return result.messages[0].contents[0].text;
    } catch {}
  }

  if (typeof result === 'string') return result;
  if (result?.message && typeof result.message === 'string') return result.message;
  if (result?.message?.content && typeof result.message.content === 'string') return result.message.content;

  return JSON.stringify(result);
};

/* Hook: creates an absolutely positioned helper element in document.body near selection coordinates */
function useSelectionAnchor(editorRef: React.RefObject<any>) {
  const anchorRef = React.useRef<HTMLDivElement | null>(null);

  const ensureAnchor = React.useCallback(() => {
    if (!anchorRef.current) {
      const el = document.createElement('div');
      el.style.position = 'absolute';
      el.style.width = '1px';
      el.style.height = '1px';
      el.style.pointerEvents = 'none';
      el.style.zIndex = '2147483647';
      document.body.appendChild(el);
      anchorRef.current = el;
    }
    return anchorRef.current;
  }, []);

  const updateAnchorToSelection = React.useCallback(
    (pos: number) => {
      const ed = editorRef.current;
      const anchorEl = ensureAnchor();
      if (!ed || !ed.view || !anchorEl) return anchorEl;

      try {
        const coords = ed.view.coordsAtPos(pos);
        const x = coords.left;
        const y = coords.bottom + window.scrollY + 6; // offset below the selection
        anchorEl.style.left = `${x}px`;
        anchorEl.style.top = `${y}px`;
        anchorEl.style.display = 'block';
      } catch {
        anchorEl.style.display = 'none';
      }
      return anchorEl;
    },
    [editorRef, ensureAnchor]
  );

  const cleanup = React.useCallback(() => {
    if (anchorRef.current) {
      try {
        document.body.removeChild(anchorRef.current);
      } catch {}
      anchorRef.current = null;
    }
  }, []);

  return { updateAnchorToSelection, cleanup, anchorRef };
}

export default function EditorInlineAIPromptWithMenuFix(): JSX.Element {
  const editorRef = React.useRef<any>(null);
  const abortControllerRef = React.useRef<AbortController | null>(null);
  const { updateAnchorToSelection, cleanup, anchorRef } = useSelectionAnchor(editorRef);

  const [outputs, setOutputs] = React.useState<InlineAIPromptOutputInterface[]>([]);
  const [streaming, setStreaming] = React.useState<boolean>(false);
  const [selectedText, setSelectedText] = React.useState<string>('');
  const [selectionRange, setSelectionRange] = React.useState<{ start: number; end: number }>({ start: 0, end: 0 });
  const [showPrompt, setShowPrompt] = React.useState<boolean>(false);
  const [anchorEl, setAnchorEl] = React.useState<HTMLElement | undefined>(undefined);

  const clickedInsidePromptRef = React.useRef(false);

  const readSelection = React.useCallback(() => {
    const ed = editorRef.current;
    if (!ed || !ed.view) return { text: '', from: 0, to: 0 };
    const { from, to } = ed.view.state.selection;
    const text = ed.view.state.doc.textBetween(from, to, '\n');
    return { text, from, to };
  }, []);


  const getEditorHtml = React.useCallback(() => {
  const ed = editorRef.current;
  if (!ed || !ed.view) return '';
  try {
    // The editor's DOM contains the rendered HTML
    const dom = ed.view.dom as HTMLElement;
    // Optionally sanitize or strip editor-specific wrappers here
    return dom.innerHTML;
  } catch {
    return '';
  }
}, []);

  // Document mousedown listener to detect clicks inside prompt (prevents immediate close)
  React.useEffect(() => {
    const onDocMouseDown = (ev: MouseEvent) => {
      try {
        const path = (ev as any).composedPath?.() || (ev as any).path || [];
        let inside = false;
        for (const p of path) {
          if (
            p &&
            p.classList &&
            (p.classList.contains('k-inlineai') ||
              p.classList.contains('k-inline-ai-prompt') ||
              p.classList.contains('k-inline-ai'))
          ) {
            inside = true;
            break;
          }
        }
        if (!inside) {
          const target = ev.target as HTMLElement | null;
          if (
            target &&
            target.closest &&
            target.closest('.k-inlineai, .k-inline-ai-prompt, .k-inline-ai')
          )
            inside = true;
        }
        clickedInsidePromptRef.current = inside;
      } catch {
        clickedInsidePromptRef.current = false;
      }
    };

    document.addEventListener('mousedown', onDocMouseDown, true);
    return () => document.removeEventListener('mousedown', onDocMouseDown, true);
  }, []);

  // Attach native listeners once editor view is available; detect selection changes
  React.useEffect(() => {
    let mounted = true;
    const tryAttach = () => {
      if (!mounted) return;
      const ed = editorRef.current;
      if (ed && ed.view && ed.view.dom) {
        const dom = ed.view.dom as HTMLElement;

        const onSelect = () => {
          const { text, from, to } = readSelection();
          if (text && text.trim().length > 0) {
            setSelectedText(text);
            setSelectionRange({ start: from, end: to });
            const el = updateAnchorToSelection(from);
            setAnchorEl(el || undefined);
            setShowPrompt(true);
          } else {
            window.setTimeout(() => {
              if (!clickedInsidePromptRef.current) {
                setShowPrompt(false);
                setSelectedText('');
                setOutputs([]);
                setAnchorEl(undefined);
              } else {
                clickedInsidePromptRef.current = false;
              }
            }, 50);
          }
        };

        dom.addEventListener('mouseup', onSelect);
        dom.addEventListener('keyup', onSelect);

        return () => {
          dom.removeEventListener('mouseup', onSelect);
          dom.removeEventListener('keyup', onSelect);
        };
      }
      setTimeout(tryAttach, 200);
    };

    const cleanupListener = tryAttach();
    return () => {
      mounted = false;
      if (typeof cleanupListener === 'function') cleanupListener();
    };
  }, [readSelection, updateAnchorToSelection]);

  // cleanup anchor on unmount
  React.useEffect(() => {
    return () => cleanup();
  }, [cleanup]);

  const onPromptRequest = async (prompt: string) => {
    if (!prompt || !selectedText) return;
    setStreaming(true);
    const ac = new AbortController();
    abortControllerRef.current = ac;

    try {
      const reply = await getSuggestion(prompt, selectedText, ac.signal);
      if (!ac.signal.aborted) {
        setOutputs([{ id: Date.now(), responseContent: reply, prompt }]);
      }
    } catch (err: any) {
      console.error('AI request error:', err);
      setOutputs([
        {
          id: Date.now(),
          responseContent: 'Error contacting AI service: ' + (err?.message || err),
          prompt,
        },
      ]);
    } finally {
      setStreaming(false);
      abortControllerRef.current = null;
    }
  };

  const onPromptCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setStreaming(false);
    }
  };

  const onCommandExecute = (commandData: CommandItemInterface) => {
    if (commandData.prompt && selectedText) {
      const prompt = commandData.prompt(selectedText);
      onPromptRequest(prompt);
    }
  };

  const onOutputAction = (action: OutputActionInterface, output: InlineAIPromptOutputInterface) => {
    const ed = editorRef.current;
    if (!ed || !ed.view) return;
    const { state, dispatch } = ed.view;
    const { start, end } = selectionRange;

    switch (action.id) {
      case 'copy':
        try {
          navigator.clipboard.writeText(output.responseContent);
        } catch {}
        break;
      case 'insert': {
        const pNode = state.schema.nodes.paragraph.create(null, state.schema.text(output.responseContent));
        dispatch(state.tr.insert(end, pNode));
        break;
      }
      case 'replace':
        dispatch(state.tr.insertText(output.responseContent, start, end));
        break;
      case 'discard':
        setOutputs((prev) => prev.filter((o) => o.id !== output.id));
        break;
      default:
        break;
    }

    setShowPrompt(false);
    setSelectedText('');
    setOutputs([]);
    setAnchorEl(undefined);
  };

  return (
    <div style={{ width: '100%', padding: 12 }}>
      <div style={{ marginBottom: 8, color: '#555' }}>
        Select text inside the editor to trigger the inline AI prompt. Click the burger to open commands.
      </div>

      <Editor
        ref={editorRef}
        tools={[
          [Bold, Italic, Underline, Strikethrough],
          [Subscript, Superscript],
          [AlignLeft, AlignCenter, AlignRight, AlignJustify],
          [Indent, Outdent],
          [OrderedList, UnorderedList],
          FontSize,
          FontName,
          FormatBlock,
          [Undo, Redo],
          [Link, Unlink, InsertImage, ViewHtml],
          [InsertTable],
          [AddRowBefore, AddRowAfter, AddColumnBefore, AddColumnAfter],
          [DeleteRow, DeleteColumn, DeleteTable],
          [MergeCells, SplitCell],
        ]}
        defaultEditMode="div"
        defaultContent={content}
        contentStyle={{ height: 480 }}
      />

      {showPrompt && (
        <InlineAIPrompt
          width={544}
          streaming={streaming}
          enableSpeechToText={true}
          outputs={outputs}
          anchor={anchorEl || editorRef.current?.view?.dom || undefined}
          commands={commands}
          onCommandExecute={onCommandExecute}
          onPromptRequest={onPromptRequest}
          onPromptCancel={onPromptCancel}
          outputActions={outputActions}
          onOutputAction={onOutputAction}
          onDiscard={(o) => setOutputs((prev) => prev.filter((x) => x.id !== o.id))}
          show={showPrompt}
        />
      )}
    </div>
  );
}